from django import forms
from django.shortcuts import render

class NewTaskForm(forms.Form):
    name = forms.CharField(label="New Task :")
    age = forms.IntegerField(label="Age :", min_value=18 ,max_value=30 )

    
tasks = []
age = []
# Create your views here.
def index(request):
    return render(request, "tasks/index.html", {
        'tasks' : tasks, 'age': age
    })

def add(request):
    if request.method == "POST":
        form = NewTaskForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data["name"]
            year = form.cleaned_data["age"]
            age.append(year)
            tasks.append(name)
        else:
            return render(request, "tasks/add.html",{
                'form': form
            })
    return render(request, "tasks/add.html",{
        "form": NewTaskForm()
    })


